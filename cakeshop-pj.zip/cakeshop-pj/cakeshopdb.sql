-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 14, 2024 at 05:35 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cakeshopdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `cakelist`
--

CREATE TABLE `cakelist` (
  `id` int(40) NOT NULL,
  `name` varchar(50) NOT NULL,
  `price` int(30) NOT NULL,
  `description` varchar(30) NOT NULL,
  `img` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cakelist`
--

INSERT INTO `cakelist` (`id`, `name`, `price`, `description`, `img`) VALUES
(3, 'Cake', 300000, 'Dark Chocolate', 'dc.jpg'),
(4, 'Cake', 300000, 'Dark Choco', 'dc.jpg'),
(5, 'Cake', 300000, 'Choco', 'dc.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(40) NOT NULL,
  `name` varchar(40) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `message`) VALUES
(1, 'Mg Mg Ko', 'uyghjh@gmail.com', 'very good'),
(2, 'Santho', 'djkjkdj@gmail.com', 'Hi');

-- --------------------------------------------------------

--
-- Table structure for table `icecreamlist`
--

CREATE TABLE `icecreamlist` (
  `id` int(40) NOT NULL,
  `name` varchar(50) NOT NULL,
  `price` int(30) NOT NULL,
  `description` varchar(30) NOT NULL,
  `img` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `icecreamlist`
--

INSERT INTO `icecreamlist` (`id`, `name`, `price`, `description`, `img`) VALUES
(3, 'Ice Cream ', 30000, 'Icecream Sandea', 'ic1.jpg'),
(4, 'Ice Cream ', 30000, 'icecream', 'offer.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `id` int(40) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone` int(30) NOT NULL,
  `address` varchar(30) NOT NULL,
  `item_name` varchar(30) NOT NULL,
  `price` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`id`, `name`, `phone`, `address`, `item_name`, `price`) VALUES
(1, 'Mg Mg Ko', 2147483647, 'Yangon', 'Ice Cream ', 30000),
(2, 'Mg Mg Ko', 2147483647, 'Yangon', 'Ice Cream ', 30000),
(3, 'Mg Mg Ko', 2147483647, 'Yangon', 'Cake', 300000),
(5, 'Kaung Kaung', 2147483647, 'paung\r\n', 'Cake', 300000),
(6, 'Santho', 2147483647, 'Yangon', 'Cake', 300000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cakelist`
--
ALTER TABLE `cakelist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `icecreamlist`
--
ALTER TABLE `icecreamlist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cakelist`
--
ALTER TABLE `cakelist`
  MODIFY `id` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `icecreamlist`
--
ALTER TABLE `icecreamlist`
  MODIFY `id` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `id` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
