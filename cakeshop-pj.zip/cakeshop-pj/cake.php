<!DOCTYPE html>
<html lang="en">

<header>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</header>
<head>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CakeZone</title>
</head>
<body>
<div class="header">
<nav class="navbar navbar-expand-lg navbar-warning bg-info">
  <div class="container-fluid">
    <img src="img/Cake.jpg" width="60" class="rounded-circle" href=  /></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDarkDropdown" aria-controls="navbarNavDarkDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" style="color:black; font-weight:bold;" href="navbarDarkDropdownMenuLink" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Items List
          </a>
          <ul class="dropdown-menu dropdown-menu-light" aria-labelledby="navbarDarkDropdownMenuLink">
          <li><a class="dropdown-item" href="index.html">Home</a></li>
            <li><a class="dropdown-item" href="icecream.php">Icecream</a></li>
          <li><a class="dropdown-item" href="contact.php">Contact Us</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
</div>

<div class=" mb-3">
  <img src="img/display.jpg" class="card-img-top" height="500px" width="400" alt="...">
  <div class="card-body">
    <h5 class="card-title">Welcome to Our Cake Ordering Page!</h5>
    <p class="card-text">Indulge in a world of sweetness with our wide variety of cakes, perfect for every occasion. Whether you’re celebrating a birthday, anniversary, or any special moment, we have the perfect cake for you. From rich chocolate to velvety vanilla, our classic cakes are timeless favorites. Personalize your cake with unique designs and flavors to make your celebration truly special. Choose from a variety of themes, including superheroes, princesses, and more, to delight the little ones. We also offer gluten-free, vegan, and sugar-free cakes to cater to all dietary needs.

We use only the finest ingredients to ensure every bite is delicious. Our skilled bakers craft each cake with love and precision. Enjoy prompt and reliable delivery right to your doorstep. Your happiness is our top priority, and we strive to exceed your expectations with every order.

Browse through our gallery to see our beautiful creations and place your order today. We can’t wait to be a part of your special moments!</p>
    <p class="card-text"><small class="text-muted"></small></p>
  </div>
</div>
<section class="hot_section layout_padding">
    <div class="container">
      <div class="heading_container">
        <h2>
          Our Cake List
        </h2>
        <hr>
      </div>
      <p>
      You can choose whatever you want!
      </p>
    </div>
  </section>
  <div class="container">
       <div class="row">
    <?php
error_reporting(1);
include('connection.php');
$data="SELECT * FROM cakelist ORDER BY id DESC";
$val=$con->query($data);
if ($val->num_rows > 0) {
while(list($id,$name,$price,$dis,$img) = mysqli_fetch_array($val)){
    echo "<div class='col-4'>
    <div class='card'>
    <img src='admin/img/$img'
    height='300' width='300' style='border-radius:20px;'  />
    <div class='card-content'>
        <h2 >$name</h2>
        <p style='color:green'>Price - $price MMK</p>
        <p>$dis</p>
        <center>  <a href='order.php?name=$name&price=$price'>
        <img src='img/buying.jpg'  width=65 class='imageee'/> </a></center>
    </div>
</div>
<br><br>
    </div>";
  
}}else{
    echo "<h1 colspan='8' class='text-center'>
   <b> No data available</b></h1>";
}
?>
</div>
</div>

<footer class="footer bg-dark text-white text-center p-4">
    <p>
      &copy;<a class="text-white" href="index.html">CakeZone</a>. 2024 All Rights Reserved. Design by
      <a href="">Than Tun Zaw</a>
    </p>
    </footer>

<style>


    

.card {
    background-color: white;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    overflow: hidden;
    width: 300px;
    margin: 1rem;
    transition: transform 0.2s;
}

.card:hover {
    transform: scale(1.05);
}

.imageee:hover {
  transform: scale(1.3);
}

.card-content {
    padding: 1rem;
}

.card-content h2 {
    margin-top: 0;
    font-size: 1.5rem;
}

.card-content p {
    color: #555;
}

/* Added padding and hover effect to navbar links */
.navbar-nav .nav-item .nav-link {
  color: black;
  font-weight: bold;
  padding: 10px 20px;
}

.navbar-nav .nav-item .nav-link:hover {
  background-color: #ffcc99;
  color: #fff;
  transition: 0.3s ease;
  border-radius: 10px;
}

/* Dropdown menu styling */
.dropdown-menu {
  background-color: #f8f9fa;
}

.dropdown-item {
  padding: 10px 20px;
  transition: background-color 0.3s ease;
}

.dropdown-item:hover {
  background-color: #ffcc99;
  color: white;
}

  </style>


  







</body>
</html>