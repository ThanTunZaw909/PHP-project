<body style="background-color:#f2f2f2;">
<div>
    <br>
      <center>
      <img src="img/thankss.png" width="150"/><br>
      <img src="img/ordersuccess.gif" style=" border-radius:30px;" width="600"/><br>
      <p>Your order is on the way to you.</p>
     <a href="index.html"> <img src="img/home.png" width="100"/></a>
      <br>
      </center>
       </div>
</body>

